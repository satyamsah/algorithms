package stringcompression;


import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class StringCompression {

	
	public static void main(String args[]){
		
		
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		//String str="aaabbccaa";
		StringBuilder sb1=new StringBuilder();
		for(int i=0;i<n;i++){
			sb1.append(sc.next());
		}
		String str=sb1.toString();
		//String str="aaabbccaa";
		sc.close();
		
		
		Map<Character, Integer> map= new LinkedHashMap<>();
		
		for(int i=0;i<str.length();i++){
			
			if(!map.containsKey(str.charAt(i))){
				map.put(str.charAt(i), 1);
			}
			else{
				map.put(str.charAt(i), map.get(str.charAt(i))+1);
			}
			
		}
		
		
		
		StringBuilder sb=new StringBuilder();
		for(Map.Entry<Character, Integer> singleval: map.entrySet()){
			
			sb.append(singleval.getKey());
			sb.append(singleval.getValue());
			
		}
		
		System.out.println(sb.toString());
		
		
		
	}
}
